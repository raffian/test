

run the app using command:

    mvn clean spring-boot:run
