package devops.compute.api.vnode.service.virtualnode.impl;

public class VMConstants {

    public static final String NAME_FIELD = "name";


}
