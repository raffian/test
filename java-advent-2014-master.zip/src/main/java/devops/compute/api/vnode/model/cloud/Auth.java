package devops.compute.api.vnode.model.cloud;

public class Auth {

    private final String user;
    private final String password;

    public Auth(String u, String p) {
        this.user = u;
        this.password = p;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }



}
