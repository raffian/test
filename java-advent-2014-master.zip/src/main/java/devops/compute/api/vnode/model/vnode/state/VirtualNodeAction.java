package devops.compute.api.vnode.model.vnode.state;

public enum VirtualNodeAction {

    POWER_ON  ("power_on"),
    POWER_OFF ("power_off"),
    RESET     ("reset"),
    REBOOT    ("reboot"),
    SUSPEND   ("suspend");

    private final String action;

    VirtualNodeAction(String action){
        this.action = action;
    }

    public String action(){
        return action;
    }

    public boolean is(VirtualNodeAction act){
        return (act != null && (this.action == act.action()));
    }
}
