package devops.compute.api.vnode.model.cloud;

public class CloudCoordinates {

    private String region;
    private String datacenter;
    private String zone;

}
