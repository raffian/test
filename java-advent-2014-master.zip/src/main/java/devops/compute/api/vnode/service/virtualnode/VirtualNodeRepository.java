package devops.compute.api.vnode.service.virtualnode;


public interface VirtualNodeRepository /*extends Repository<VirtualNode, String> */{

    /**
     * Finds information for a single virtual node
     * @param id    The id of the virtual node.
     * @return      Information for the virtual node; if none found,
     *                  returns an empty {@link java.util.Optional} object.
     *
    Optional<VirtualNode> findOne(String id);

    /**
     * Finds all virtual nodes in the compute system.
     * @return
     *
    List<VirtualNode> findAll();

    /**
     * Get current virtual node state by id.
     * @param id    The id of the requested virtual node entry.
     *
    VirtualNode viewState(String id);

    /**
     * Discards the virtual node from compute system.
     * @param deleted
     *
    void delete(VirtualNode deleted);

    /**
     * Saves/Create a new virtual node .
     * @param saved The information for the virtual node .
     * @return
     *
    VirtualNode save(VirtualNode obj);

    /**
     * Invokes power action on new virtual node .
     * @param    the virtual node on which to invoke the action.
     * @param    the action to invoke
     * @return
     *
    VirtualNode invoke(String id, VirtualNodeAction action);
    */
}
