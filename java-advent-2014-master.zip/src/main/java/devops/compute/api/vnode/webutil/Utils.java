package devops.compute.api.vnode.webutil;

import java.net.MalformedURLException;
import java.net.URL;

import com.vmware.vim25.mo.HostSystem;

public class Utils {

    public static final boolean     IGNORE_CERT = true;
    public static final HostSystem  NO_HOST     = null;

    public static URL newURL(String urlString){
        URL url = null;
        try{
            if(urlString == null){
                throw new RuntimeException("URL cannot be null.");
            }
            return new URL(urlString);

        }catch(MalformedURLException ex){
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    public static void log(Object obj){
        if(obj != null){
            System.out.println(obj.toString());
        }
    }

}
