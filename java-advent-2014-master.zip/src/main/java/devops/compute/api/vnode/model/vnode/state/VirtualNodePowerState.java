package devops.compute.api.vnode.model.vnode.state;


public enum VirtualNodePowerState {

    ONLINE     ("poweredOn"),
    OFF        ("poweredOff"),
    SUSPENDED  ("suspended");

    private final String powerState;

    VirtualNodePowerState(String state){
        this.powerState = state;
    }

    public String state(){
        return powerState;
    }

    public boolean is(VirtualNodePowerState ps){
        return (ps != null && (this.powerState == ps.state()));
    }


    /*
    //@JsonCreator
    public static VirtualNodePowerState fromValue(String value) {
        return ...
    }*/

}
