package devops.compute.api.vnode.service.virtualnode.connector;

import devops.compute.api.vnode.model.cloud.CloudTarget;

public interface CloudConnectorFactory<T> {

    public T createConnector() throws Exception;
    public T createConnector(CloudTarget ct) throws Exception;

}
