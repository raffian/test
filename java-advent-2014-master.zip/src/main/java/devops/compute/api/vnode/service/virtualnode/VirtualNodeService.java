package devops.compute.api.vnode.service.virtualnode;

import java.util.List;

import devops.compute.api.vnode.model.vnode.VirtualNodeDTO;
import devops.compute.api.vnode.model.vnode.state.VirtualNodeAction;


public interface VirtualNodeService {
    /**
     * Finds a single virtual node.
     * @param id    The id of the requested virtual node entry.
     */
    VirtualNodeDTO findById(String id);

    /**
     * Finds all virtual nodes.
     * @return      All virtual node entries.
     */
    List<VirtualNodeDTO> findAll();

    /**
     * Get current virtual node state by id.
     * @param id    The id of the requested virtual node entry.
     */
    VirtualNodeDTO viewState(String id);

    /**
     * Provisions a new virtual node.
     * @param vnode   virtual node specification
     * @return        the virtual node information
     */
    VirtualNodeDTO create(VirtualNodeDTO vnode);

    /**
     * Updates virtual node information .
     * @throws exception, if no such virtual node exists
     */
    VirtualNodeDTO update(VirtualNodeDTO vnode);

    /**
     * Invokes action on virtual node
     * @throws exception, if no such virtual node exists
     */
    VirtualNodeDTO invoke(String id, VirtualNodeAction action)
            throws VirtualNodeNotFoundException,
                   VirtualNodeManagementException;

    /**
     * Dicards a virtual node from compute cloud.
     * @param id    Virtual node id
     * @throws      If no virtual node is found for the specified id
     */
    VirtualNodeDTO delete(String id);

}
