package devops.compute.api.vnode.model.cloud;

import java.net.URL;

import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(staticName = "from")
public class CloudTarget {

    @Getter @NonNull private final Auth auth;
    @Getter @NonNull private final URL url;






}
