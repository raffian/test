package devops.compute.api.vnode.service.virtualnode.impl;

import static devops.compute.api.vnode.webutil.Utils.NO_HOST;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vmware.vim25.VirtualHardware;
import com.vmware.vim25.mo.Task;
import com.vmware.vim25.mo.VirtualMachine;

import devops.compute.api.vnode.model.cloud.CloudTarget;
import devops.compute.api.vnode.model.vnode.VirtualNode;
import devops.compute.api.vnode.model.vnode.VirtualNodeDTO;
import devops.compute.api.vnode.model.vnode.state.VirtualNodeAction;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeManagementException;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeNotFoundException;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeService;

@Service("virtualNodeService")
public class VCenterVirtualNodeRepository implements VirtualNodeService {

    @Autowired
    private CloudTarget cloudTarget;

    @Autowired
    private VCenterServiceConnectorFactory connectorFactoryService;

    public void init(){
        log.info("connectorFactoryService::init()");
        log.info(this.cloudTarget.toString());
    }

    //private final List<Todo> list = new ArrayList<Todo>();
    private final AtomicLong idGenerator = new AtomicLong(0);

    @Override
    public VirtualNodeDTO findById(String id) {
        return convertToDTO(randomVirtualNode("findById: " + id));
    }
    @Override
    public List<VirtualNodeDTO> findAll() {
        return Arrays.asList(convertToDTO(randomVirtualNode("findAll")));
    }
    @Override
    public VirtualNodeDTO viewState(String id) {
        return convertToDTO(randomVirtualNode("viewState: " + id));
    }
    @Override
    public VirtualNodeDTO create(VirtualNodeDTO vnode) {
        return convertToDTO(randomVirtualNode("create: "));
    }
    @Override
    public VirtualNodeDTO update(VirtualNodeDTO vnode) {
        return convertToDTO(randomVirtualNode("update: " + vnode.getId()));
    }
    @Override
    public VirtualNodeDTO invoke(String id, VirtualNodeAction action)
            throws VirtualNodeNotFoundException,
                   VirtualNodeManagementException{

/*

        VirtualMachine vm = find(id);

            if(vm == null)){
                throw new VirtualNodeNotFoundException(id);
            }
            else{

                Task response = null;
                if(VirtualNodeAction.POWER_ON.is(action)){
                    response = vm.powerOnVM_Task(NO_HOST);
                }
                else if(VirtualNodeAction.POWER_OFF.is(action)){
                    response = vm.powerOffVM_Task();
                }
                else if(VirtualNodeAction.RESET.is(action)){
                    response = vm.resetVM_Task();
                }
                else{
                    throw new VirtualNodeManagementException(id, "Invalid power action: " + action);
                }

                if (response.waitForTask() == Task.SUCCESS){
                    virtualMachineToDTO(find(id));
                }else{
                    throw new VirtualNodeManagementException(id, "Power action not successful");
                }
            }else{

            }
        }catch(Exception e){
            throw new Vir
        }*/

        return null;
    }

    private VirtualMachine find(String id) throws Exception {
        return
            connectorFactoryService
                .newSearch()
                .findVirtualNode(id);
    }


    @Override
    public VirtualNodeDTO delete(String id) {
        return convertToDTO(randomVirtualNode("deleted: " + id));
    }

    private VirtualNode randomVirtualNode(String msg){
        return
            VirtualNode.builder()
                .cpus(2)
                .id(nextId())
                .diskMode(msg)
                .diskSize(10000)
                .memory(4096)
                .zone("dev")
                .region("us-west")
                .build();
    }

    private VirtualNodeDTO virtualMachineToDTO(VirtualMachine vm) {

        VirtualHardware hardware = vm.getConfig().getHardware();
        return
            VirtualNodeDTO
            .builder()
                .id(vm.getName())
                .memory(hardware.getMemoryMB())
                .cpus(hardware.getNumCPU())
                .diskMode("NA")
                .diskSize(10000)
                .region("us-ofi-west")
                .zone("dev")
                .build();
    }


    private VirtualNodeDTO convertToDTO(VirtualNode model) {
        model = (model == null)? VirtualNode.createEmpty() : model;

        VirtualNodeDTO dto = null;//new VirtualNodeDTO();
        dto.setId(model.getId());
        dto.setMemory(model.getMemory());
        dto.setCpus(model.getCpus());
        dto.setDiskMode(model.getDiskMode());
        dto.setDiskSize(model.getDiskSize());
        dto.setRegion(model.getRegion());
        dto.setZone(model.getZone());
        return dto;
    }

    private String nextId() {
        return String.valueOf(idGenerator.incrementAndGet());
    }

    private boolean notNull(Object o) {
        return (o != null);
    }


    private static final Logger log = LoggerFactory
            .getLogger(VCenterVirtualNodeRepository.class);


    /*


       private Todo findTodoById(String id) {
        Todo result = repository.get(id);
        if (result != null) {
            return result;
        } else {
            throw new TodoNotFoundException(id);
        }

    }


    @Autowired
    VCenterVirtualNodeRepository(VirtualNodeRepository repository) {
        // this.repository = repository;
        LOGGER.info("VCenter Repo init!");
    }

    @Override
    public TodoDTO create(TodoDTO todo) {
        LOGGER.info("Creating a new todo entry with information: {}", todo);

        Todo persisted = Todo.getBuilder().id(nextId()).title(todo.getTitle())
                .description(todo.getDescription()).build();

        repository.put(persisted.getId(), persisted);
        list.add(persisted);
        LOGGER.info("Created a new todo entry with information");

        return convertToDTO(persisted);
    }

    private void populateList() {
        Todo t1 = Todo.getBuilder().id(nextId()).description("somedesc1")
                .title("title1").powerState(VNodePowerState.ONLINE).build();
        Todo t2 = Todo.getBuilder().id(nextId()).description("somedesc2")
                .title("title2").powerState(VNodePowerState.OFF).build();
        Todo t3 = Todo.getBuilder().id(nextId()).description("somedesc3")
                .title("title3").powerState(VNodePowerState.ONLINE).build();
        list.add(t1);
        list.add(t2);
        list.add(t3);
        repository.put(t1.getId(), t1);
        repository.put(t2.getId(), t2);
        repository.put(t3.getId(), t3);
    }

    @Override
    public TodoDTO delete(String id) {
        LOGGER.info("Deleting a todo entry with id: {}", id);

         //Todo deleted = findTodoById(id); repository.remove(id);
          //LOGGER.info("Deleted todo entry with informtation: {}", deleted);

        return convertToDTO(null);
    }

    @Override
    public List<TodoDTO> findAll() {
        populateList();
        LOGGER.info("Finding all todo entries.");
        // List<Todo> todoEntries = repository.findAll();
        LOGGER.info("Found {} todo entries", list.size());
        return convertToDTOs(list);
    }

    @Override
    public TodoDTO findById(String id) {
        LOGGER.info("Finding todo entry with id: {}", id);

        Todo found = findTodoById(id);
        LOGGER.info("Found todo entry: {}", found);
        Todo t3 = Todo.getBuilder().id(nextId()).description("somedesc3")
                .title("title3").powerState(VNodePowerState.ONLINE).build();
        return convertToDTO(t3);
    }

    @Override
    public TodoDTO update(TodoDTO todo) {
        LOGGER.info("Updating todo entry with information: {}", todo);

         //Todo updated = findTodoById(todo.getId());
         //updated.update(todo.getTitle(), todo.getDescription()); updated =
         //repository.save(updated);
         //LOGGER.info("Updated todo entry with information: {}", updated);
        return convertToDTO(null);
    }

    private List<TodoDTO> convertToDTOs(List<Todo> models) {
        return models.stream().map(this::convertToDTO).collect(toList());
    }






    public void powerONVirtualNode(VirtualNode vms) {
        VCenterCatalogSearch search = null;
        try{
            search =
                VCenterCatalogSearch
                    .newSearch(newConnector());
            search
                .findVirtualNode("")
                .powerOnVM_Task(NO_HOST);
            return null;
            //task.waitForMe() ==Task.SUCCESS
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            search.close();
        }
        return null;
    }*/

}
