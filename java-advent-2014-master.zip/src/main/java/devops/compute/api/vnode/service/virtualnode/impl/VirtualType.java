package devops.compute.api.vnode.service.virtualnode.impl;

import com.vmware.vim25.mo.Datacenter;
import com.vmware.vim25.mo.ResourcePool;
import com.vmware.vim25.mo.VirtualMachine;

import devops.compute.api.vnode.model.vnode.state.VirtualNodeManagementState;

public enum VirtualType {

    VIRTUAL_MACHINE("VirtualMachine", VirtualMachine.class),
    DATACENTER     ("Datacenter",     Datacenter.class),
    RESOURCE_POOL  ("ResourcePool",   ResourcePool.class);

    private final String id;
    private final Class<?> type;

    private VirtualType(String id, Class<?> type) {
        this.id = id;
        this.type = type;
    }

    public String id() {
        return id;
    }

    public Class<?> type(){
        return this.type;
    }

    public boolean is(VirtualType vt){
        return (vt != null && ((this.id.equals(vt.id()) && this.type.equals(vt.type))));
    }

}
