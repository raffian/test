package devops.compute.api.vnode.service.virtualnode.impl.esx;

public class ManageVirtualMachinePowerState {

    public ManageVirtualMachinePowerState() {
        // TODO Auto-generated constructor stub
    }

}
