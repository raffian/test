package devops.compute.api.vnode.service.virtualnode.impl;

import com.vmware.vim25.mo.ServiceInstance;

import devops.compute.api.vnode.service.virtualnode.connector.CloudConnector;


public class VCenterConnector implements CloudConnector<ServiceInstance> {

    private final ServiceInstance service;

    public VCenterConnector(ServiceInstance rawConnector) throws Exception {
        service = rawConnector;
    }

    @Override
    public void dispose(){
        if(service != null){
            service.getServerConnection().logout();
        }
    }

    @Override
    public ServiceInstance getConnector() {
        return service;
    }
}
