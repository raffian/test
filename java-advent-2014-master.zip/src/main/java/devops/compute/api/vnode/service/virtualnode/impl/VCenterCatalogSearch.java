package devops.compute.api.vnode.service.virtualnode.impl;

import java.util.HashMap;

import com.vmware.vim25.mo.Datacenter;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ResourcePool;
import com.vmware.vim25.mo.ServiceInstance;
import com.vmware.vim25.mo.VirtualMachine;

import devops.compute.api.vnode.model.cloud.CloudTarget;

public class VCenterCatalogSearch  {

    private ServiceInstance serviceInstance;

    protected final static
        HashMap<Class<?>, String> types =
            new HashMap<Class<?>, String>();

    static {
        types.put(VirtualMachine.class, "VirtualMachine");
        types.put(Datacenter.class,     "Datacenter");
        types.put(ResourcePool.class,   "ResourcePool");
    }

    private VCenterCatalogSearch(){}

    public VCenterCatalogSearch(ServiceInstance si) {
        this.serviceInstance = si;
    }

    public VirtualMachine findVirtualNode(String name) throws Exception {
        return find(name, VirtualMachine.class);
    }

    public Datacenter findDataCenter(String name) throws Exception {
        return find(name, Datacenter.class);
    }

    public ResourcePool findDataCenterResourcePool(Datacenter dc) throws Exception {
        return findFirst(dc, ResourcePool.class);
    }

    public <T> T find(String vmname, Class<T> typeClass) throws Exception {
        return find(vmname, serviceInstance.getRootFolder(), typeClass);
    }

    public <T> T find(String vmname, ManagedEntity folder, Class<T> typeClass) throws Exception {
        return
            typeClass.cast(
                new InventoryNavigator(serviceInstance.getRootFolder())
                    .searchManagedEntity(getInventoryTypeName(typeClass), vmname));
    }

    public <T> T findFirst(ManagedEntity entity, Class<T> typeClass) throws Exception {
        return
            typeClass.cast(
                new InventoryNavigator(entity)
                    .searchManagedEntities(getInventoryTypeName(typeClass))[0]);
    }

    protected String getInventoryTypeName(Class<?> typeClass){
        return types.get(typeClass);
    }
}
