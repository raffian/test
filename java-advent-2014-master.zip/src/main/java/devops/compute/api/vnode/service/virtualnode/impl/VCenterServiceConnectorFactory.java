package devops.compute.api.vnode.service.virtualnode.impl;

import static devops.compute.api.vnode.webutil.Utils.IGNORE_CERT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.vmware.vim25.mo.ServiceInstance;

import devops.compute.api.vnode.model.cloud.CloudTarget;
import devops.compute.api.vnode.service.virtualnode.connector.CloudConnectorFactory;

@Service("connectorFactoryService")
public class VCenterServiceConnectorFactory implements CloudConnectorFactory<VCenterConnector> {

    @Autowired
    private CloudTarget cloudTarget;

    public void init(){
        log.info("connectorFactoryService::init()");
        log.info(this.cloudTarget.toString());
    }

    public VCenterCatalogSearch newSearch() throws Exception {
        return new VCenterCatalogSearch(createConnector().getConnector());
    }

    public VCenterConnector createConnector() throws Exception {
        return createConnector(cloudTarget);
    }

    public VCenterConnector createConnector(CloudTarget cloud) throws Exception {
        return _createConnector(cloud);
    }

    private VCenterConnector _createConnector(CloudTarget ct) throws Exception {
        return
            new VCenterConnector(
                new ServiceInstance(
                    ct.getUrl(),
                    ct.getAuth().getUser(),
                    ct.getAuth().getPassword(),
                    IGNORE_CERT));
    }

    private static final
        Logger log = LoggerFactory
            .getLogger(VCenterVirtualNodeRepository.class);

    //@Bean(destroyMethod = "dispose" )
    //@Scope("prototype")
    //@Override
}
