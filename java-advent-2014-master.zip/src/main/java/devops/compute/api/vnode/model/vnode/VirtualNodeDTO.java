package devops.compute.api.vnode.model.vnode;

import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.ToString;

import com.vmware.vim25.VirtualDevice;

@Builder
@ToString
public class VirtualNodeDTO {

    @Getter @Setter
    private String id;

    @Getter @Setter
    private String region;

    @Getter @Setter
    private String zone;

    @Getter @Setter private int cpus;
    @Getter @Setter private int memory;
    @Getter @Setter private int diskSize;
    @Getter @Setter private String diskMode;
    @Getter @Setter @Singular private List<VirtualDevice> devices;

}
