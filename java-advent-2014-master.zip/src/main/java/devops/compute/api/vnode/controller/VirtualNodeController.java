package devops.compute.api.vnode.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import devops.compute.api.vnode.model.vnode.VirtualNodeDTO;
import devops.compute.api.vnode.model.vnode.state.VirtualNodeAction;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeManagementException;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeNotFoundException;
import devops.compute.api.vnode.service.virtualnode.VirtualNodeService;


@RestController ("virtualNodeController")
@RequestMapping ("/vnodes")
public final class VirtualNodeController {

    @Autowired
    private final VirtualNodeService virtualNodeService;

    @Autowired
    VirtualNodeController(VirtualNodeService service) {
        this.virtualNodeService = service;
    }

    @PostConstruct
    public void init(){
        log.info("VirtualNode Controller init()");
    }


    // GET ==> /
    @RequestMapping(
        method = RequestMethod.GET)
    List<VirtualNodeDTO> findAll() {
        log.info("Finding all vnodes");
        List<VirtualNodeDTO> vnodes = virtualNodeService.findAll();
        log.info("Found {} vnodes entries", vnodes.size());
        return vnodes;
    }

    // GET ==> {id}
    @RequestMapping(
        value = "{id}",
        method = RequestMethod.GET)
    VirtualNodeDTO findById(@PathVariable("id") String id) {
        log.info("Finding vnodes entry with id: {}", id);
        VirtualNodeDTO vnodes = virtualNodeService.findById(id);
        log.info("Found vnodes entry with information: {}", vnodes);
        return vnodes;
    }

    // GET ==> {id}/state
    @RequestMapping(
        value = "/{id}/state",
        method = RequestMethod.GET)
    VirtualNodeDTO viewStateById(@PathVariable("id") String id) {
        VirtualNodeDTO vnode = virtualNodeService.viewState(id);
        log.info("GETTING STATE");
        return vnode;
    }

    /* CREATE */
    // POST w/ [json]
    @RequestMapping(
        method = RequestMethod.POST)
    @ResponseStatus(
        HttpStatus.CREATED)
    VirtualNodeDTO create(@RequestBody @Valid VirtualNodeDTO vnode) {
        log.info("Creating new virtual node with : {}", vnode);
        VirtualNodeDTO created = virtualNodeService.create(vnode);
        log.info("Created new vnode with information: {}", created);
        return created;
    }

    /* UPDATE */
    // PUT ==> [body]
    @RequestMapping(
        value = "{id}",
        method = RequestMethod.PUT)
    VirtualNodeDTO update(@RequestBody @Valid VirtualNodeDTO todoEntry) {
        log.info("Updating todo entry with information: {}", todoEntry);

        VirtualNodeDTO updated = virtualNodeService.update(todoEntry);
        log.info("Updated todo entry with information: {}", updated);

        return updated;
    }

    // PUT ==> {id}/poweron
    @RequestMapping(
        value = "{id}/poweron",
        method = RequestMethod.PUT)
    VirtualNodeDTO poweron(@PathVariable("id") String id)
        throws VirtualNodeNotFoundException,
               VirtualNodeManagementException {

        log.info("Invoking 'power-on' for virtual node, id: {}", id);
        VirtualNodeDTO updated =
             virtualNodeService.invoke(id, VirtualNodeAction.POWER_ON);
        return updated;
    }

    // PUT ==> {id}/poweroff
    @RequestMapping(
        value = "{id}/poweroff",
        method = RequestMethod.PUT)
    VirtualNodeDTO poweroff(@PathVariable("id") String id)
        throws VirtualNodeNotFoundException,
               VirtualNodeManagementException {
        log.info("Invoking 'power-off' on virtual node, id: {}", id);
        VirtualNodeDTO updated =
             virtualNodeService.invoke(id, VirtualNodeAction.POWER_OFF);
        return updated;
    }

    // PUT ==> {id}/reset
    @RequestMapping(
        value = "{id}/reset",
        method = RequestMethod.PUT)
    VirtualNodeDTO reset(@PathVariable("id") String id)
        throws VirtualNodeNotFoundException,
               VirtualNodeManagementException {
        log.info("Invoking 'reset' on virtual node, id: {}", id);
        VirtualNodeDTO updated =
             virtualNodeService.invoke(id, VirtualNodeAction.RESET);
        return updated;
    }


    @RequestMapping(
        value = "{id}",
        method = RequestMethod.DELETE)
    VirtualNodeDTO delete(@PathVariable("id") String id) {
        log.info("Deleting virtual node with id: {}", id);
        VirtualNodeDTO deleted = virtualNodeService.delete(id);
        log.info("Deleted virtual node with information: {}", deleted);
        return deleted;
    }


    @ExceptionHandler
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public void handleVirtualNodeNotFound(VirtualNodeNotFoundException ex) {
        log.error("Handling error with message: {}", ex.getMessage());
    }

    private static final Logger log = LoggerFactory.getLogger(VirtualNodeController.class);
}
