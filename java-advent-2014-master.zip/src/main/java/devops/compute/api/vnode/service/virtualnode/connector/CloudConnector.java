package devops.compute.api.vnode.service.virtualnode.connector;


public interface CloudConnector<T> {

    public T getConnector();
    public void dispose();
}
