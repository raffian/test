package devops.compute.api.vnode.service.virtualnode;

public class VirtualNodeNotFoundException extends Exception {

    public VirtualNodeNotFoundException(String id) {
        super(String.format("No virtual node found with id: <%s>", id));
    }

    public VirtualNodeNotFoundException(String id, String message) {
        super(message);
    }

    public VirtualNodeNotFoundException(String id, Throwable cause) {
        super(cause);
    }

    public VirtualNodeNotFoundException(String id, String message, Throwable cause) {
        super(message, cause);
    }
}
