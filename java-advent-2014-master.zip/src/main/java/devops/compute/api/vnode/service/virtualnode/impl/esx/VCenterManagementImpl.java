package devops.compute.api.vnode.service.virtualnode.impl.esx;

import static devops.compute.api.vnode.webutil.Utils.log;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.vmware.vim25.VirtualHardware;
import com.vmware.vim25.VirtualMachineCapability;
import com.vmware.vim25.VirtualMachineConfigInfo;
import com.vmware.vim25.mo.Folder;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ServiceInstance;
import com.vmware.vim25.mo.VirtualMachine;

import devops.compute.api.vnode.model.vnode.VirtualNode;
import devops.compute.api.vnode.service.virtualnode.impl.VirtualType;
public class VCenterManagementImpl {

    public static void main(String[] args) throws Exception {
        ServiceInstance si =
                new ServiceInstance(
                        new URL("https://192.168.148.128/sdk"), "root", "raffi123", true);
        VCenterManagementImpl test = new VCenterManagementImpl();
        //List<VirtualNode> vms = test.findAllVirtualNodes(si);
        //vms.forEach(vm -> System.out.println(vm.toString()));
        log(test.findVirtualNode(si, "vmesx1"));
        si.getServerConnection().logout();
      }

    public VirtualNode findVirtualNode(ServiceInstance instance, String name) throws Exception {
        ManagedEntity me =
            new InventoryNavigator(instance.getRootFolder())
                .searchManagedEntity("VirtualMachine", name);

        if(me != null){
            return createVirtualNode(
                asType(me, VirtualMachine.class));
        }
        else{
            log("no vm found by name: " + name);
            return null;
        }
    }

    public List<VirtualNode> findAllVirtualNodes(ServiceInstance instance) throws Exception {
        ManagedEntity[] results =
                new InventoryNavigator(instance.getRootFolder())
                    .searchManagedEntities(VirtualType.VIRTUAL_MACHINE.id());

        List<VirtualNode> formalResults = new ArrayList<VirtualNode>();
        if(results != null){
            for(ManagedEntity entity : results){
                formalResults.add(
                    createVirtualNode(
                            asType(entity, VirtualMachine.class)));
            }
        }
        return formalResults;
    }

    public <T> T asType(ManagedEntity me, Class<T> typeClass) {
        return typeClass.cast(me);
    }

    private VirtualNode createVirtualNode(VirtualMachine vm){
        VirtualMachineCapability vmC    = vm.getCapability();
        VirtualMachineConfigInfo vmInfo = vm.getConfig();
        VirtualHardware vmHardware      = vmInfo.getHardware();

        return
            VirtualNode.builder()
                .id(vm.getName())
                .cpus( vmHardware.getNumCPU())
                .memory(vmHardware.getMemoryMB())
                .devices(Arrays.asList(vmHardware.getDevice()))
                .build();
    }
}
