package devops.compute.api.vnode.model.vnode.state;


public class VirtualNodeState {

    private VirtualNodeManagementState mgmtState;
    private VirtualNodePowerState powerState;

    public VirtualNodeState() {
    }

    public VirtualNodeState(VirtualNodeManagementState mState, VirtualNodePowerState pState) {
        this.mgmtState  = mState;
        this.powerState = pState;
    }

    public VirtualNodeManagementState getMgmtState() {
        return mgmtState;
    }
    public void setMgmtState(VirtualNodeManagementState mgmtState) {
        this.mgmtState = mgmtState;
    }
    public VirtualNodePowerState getPowerState() {
        return powerState;
    }
    public void setPowerState(VirtualNodePowerState powerState) {
        this.powerState = powerState;
    }
}
