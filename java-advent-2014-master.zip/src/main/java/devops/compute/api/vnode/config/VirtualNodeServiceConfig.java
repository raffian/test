package devops.compute.api.vnode.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import devops.compute.api.vnode.model.cloud.Auth;
import devops.compute.api.vnode.model.cloud.CloudTarget;
import devops.compute.api.vnode.service.virtualnode.impl.VCenterVirtualNodeRepository;
import devops.compute.api.vnode.webutil.Utils;

@Configuration
public class VirtualNodeServiceConfig {

    @Value("${cloud.management.url}")
    String cloudUrl;

    @Value("${cloud.management.user}")
    String cloudUser;

    @Value("${cloud.management.pswd}")
    String cloudPassword;

    @Bean(name = "cloudTarget")
    public CloudTarget cloudTarget() {
        return
            CloudTarget.from(
                new Auth(cloudUser, cloudPassword),
                Utils.newURL(cloudUrl));
    }

    /*
    @Bean(
        initMethod = "init",
        destroyMethod = "cleanup" )
    public VCenterVirtualNodeRepository virtualNodeService(){}
    */



}
