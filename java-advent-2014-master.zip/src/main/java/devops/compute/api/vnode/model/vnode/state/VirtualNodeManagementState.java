package devops.compute.api.vnode.model.vnode.state;

public enum VirtualNodeManagementState {

    CONNECTED      ("connected"),
    DISCONNECTED   ("disconnected"),
    INACCESSIBLE   ("inaccessible"),
    INVALID        ("invalid"),
    ORPHANED       ("orphaned");

    private final String mState;

    VirtualNodeManagementState(String state) {
        this.mState = state;
    }

    public String state() {
        return mState;
    }

    public boolean is(VirtualNodeManagementState mst){
        return (mst != null && (this.mState == mst.state()));
    }
}
