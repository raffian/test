package devops.compute.api.vnode.service.virtualnode;

public class VirtualNodeManagementException extends Exception {


    public VirtualNodeManagementException(String id) {
        super(String.format("Management error: vnode(%s)", id));
    }

    public VirtualNodeManagementException(String id, String message) {
        super(String.format("Management error: vnode(%s), %s", id, message));
    }


}
