
import ofi.route.processor.SimpleBean

beans {    
    myDSLBean(ofi.route.processor.SimpleBean){
        name = "hello"
        count = 3       
    }
}

public class gbeans {}