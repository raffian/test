package ofi.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

//uncomment to add these routes to context on startup
@Component
public class MoreCamelRoutes extends RouteBuilder {

    @Override
    public void configure() {
       from("timer://mytimer?fixedRate=true&period=5000")
           .log("time ==> processor")
           .to("seda:foo");
   	}

}
