package ofi.routes;

import ofi.route.processor.ArrayListAggregationStrategy;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import ofi.route.processor.SimpleBean;
import org.apache.log4j.Logger;
import com.jayway.jsonpath.JsonPath;

@Component
public class CamelRoutes extends RouteBuilder {
    static final Logger log = Logger.getLogger(RouteBuilder.class);
    @Autowired
    SimpleBean myDSLBean;

    @Override
    public void configure() {

       from("timer://anothertimer?fixedRate=true&period=5000")
          .log("time ==> processor")
          .process((Exchange exchange) -> {
                log.info("myDSLBean -> " + myDSLBean.toString());
          })
          .to("mock:foo");
       
    }
}

     


