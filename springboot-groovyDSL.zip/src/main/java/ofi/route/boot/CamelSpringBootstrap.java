package ofi.route.boot;

import org.apache.camel.spring.boot.FatJarRouter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CamelSpringBootstrap extends FatJarRouter {

    @SuppressWarnings("static-access")
    public static void main(String[] args) {
            new SpringApplication(
                CamelSpringBootstrap.class)
                    .run(new String[]{
                            "classpath:META-INF/spring/beans.xml",
                            "classpath:META-INF/spring/gbeans.groovy"},
                         args);
    }

}


