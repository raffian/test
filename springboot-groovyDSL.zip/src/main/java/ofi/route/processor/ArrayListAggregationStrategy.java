package ofi.route.processor;


import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.CompletionAwareAggregationStrategy;
import org.apache.camel.processor.aggregate.TimeoutAwareAggregationStrategy;
import org.apache.log4j.Logger;


public class ArrayListAggregationStrategy implements TimeoutAwareAggregationStrategy, CompletionAwareAggregationStrategy {

    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        Object newBody = newExchange.getIn().getBody();
        ArrayList<Object> list = null;
        if (oldExchange == null) {
            list = new ArrayList<Object>();
            list.add(newBody);
            newExchange.getIn().setBody(list);
            return newExchange;
        } else {
            list = oldExchange.getIn().getBody(ArrayList.class);
            list.add(newBody);
            return oldExchange;
        }
    }



    @Override
    public void timeout(Exchange oldExchange, int index, int total, long timeout) {
        List list = oldExchange.getIn().getBody(ArrayList.class);
        int listSize = -1;
        if(list != null){
            listSize = list.size();
        }
        logger.info(String.format("INTERVAL TIMEOUT, list:[%d]  index:%d, total:%d, timeout:%d", listSize, index, total, timeout));
    }

    private static final Logger logger = Logger.getLogger(ArrayListAggregationStrategy.class);

    @Override
    public void onCompletion(Exchange ex) {
        logger.info(String.format("onCompletion() COMPLETED"));
    }
}